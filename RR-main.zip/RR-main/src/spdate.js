export const spdate =[
    {id:1,
    name:"Santa Pola",
    foto:"https://photo980x880.mnstatic.com/bc691f608fdd3db485690f4ff21b9678/torre-vigia-tamarit-7688589.jpg",
    textmas:"Ya tenemos en nuestra base de datos al comprador de tu vivienda",
    showMore:true,
    }  ,

    {id:2,
        name:"Santa Pola",
        foto:"https://photo980x880.mnstatic.com/acb950e1f353a3291774421199c9e7ee/club-nautico-de-santa-pola-6589921.jpg",
        textmas:"Vende rápido acertando en el precio con la tasación más precisa del mercado",
        showMore:true,
        }  ,
    
        {id:3,
            name:"Santa Pola",
            foto:"http://www.turismosantapola.es/sp/uploaded/Que%20Visitar/750x460-Barco-Museo.jpg?1535702536881",
            textmas:"No hables con un ordenador, disfruta de la experiencia de un asesor dedicado a ti",
            showMore:true,
            }  ,
        
    {id:4,
        name:"Santa Pola",
        foto:"https://www.valenciabonita.es/wp-content/uploads/2020/03/mirador-del-Faro-de-Santa-Pola.jpg",
        textmas:"Publicación gratuita en los mejores portales nacionales",
        showMore:true,
        }  ,
    
        {id:5,
            name:"Santa Pola",
            foto:"https://imgs-akamai.mnstatic.com/a6/09/a6092a21a2a3cc67c1a7c55c456562a4.jpg?quality=75&format=pjpg&height=300&fit=bounds",
            textmas:"Facilitamos la venta buscando la hipoteca al comprador de tu vivienda",
            showMore:true,
            }  ,
    
            {id:6,
                name:"Santa Pola",
                foto:"http://www.turismosantapola.es/sp/uploaded/Playas/760-Carloti-panoramica.jpg?1541146266182",
                textmas:"... y solo cobramos por todos los servicios si vendes",
                showMore:true,
                }  ,

]