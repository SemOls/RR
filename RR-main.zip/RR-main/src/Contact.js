import './App.css';

    function Contact () {
        return (
            <div>
              
     <h2 className="heading"> Rosa Rocamora servicios inmobiliarios</h2>
      <h2 className="heading" >Estamos Trabajando para Vosotros desde 1997</h2>

    <div className="parent">

         <div className="ped" >
            <p> Avenida Valencia 4, Santa Pola, 03130 </p>
            <p>   📞telefono-600856081 LLAMANOS!   </p>
            <h2 > Horario </h2>
            <p >De Lunes a Viernes </p>
            <p > a 13:30 y 17:00 a 20:30 </p>
            <p >Sábados</p>
            <p >10:00 a 13:30 y por la tarde horas concertadas.</p>
            <p >Domingos y festivos horas concertadas.</p>
         </div>

         <div className="ped" >
            <img src="https://cdn.glitch.me/5539ba06-aed1-42cf-9a61-66f8d214a4d8%2Fmapa.jpg?v=1637437965864" alt="mapa" width="800px"/>
        </div>

    </div>

    
            </div>

        )
    }
    export default Contact